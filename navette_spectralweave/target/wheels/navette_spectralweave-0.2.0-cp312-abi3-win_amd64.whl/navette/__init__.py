"""
navette
=======

Fast spectral weaving computations.
"""

# Import the compiled Rust extension so it is immediately available
from . import spectralweave

# Define what gets exported if someone runs `from navette import *`
__all__ = ["spectralweave"]