# start maturin patch
def _maturin_dll_patch():
    import os
    import sys
    libs_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, "navette_smatrix.libs"))
    if os.path.isdir(libs_dir):
        if sys.version_info >= (3, 8) and hasattr(os, 'add_dll_directory'):
            os.add_dll_directory(libs_dir)
_maturin_dll_patch()
del _maturin_dll_patch
# end maturin patch
from .navette_smatrix import *

__doc__ = navette_smatrix.__doc__
if hasattr(navette_smatrix, "__all__"):
    __all__ = navette_smatrix.__all__