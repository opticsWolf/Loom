"""
navette
=======

Python bindings for the Navette unified color engine (Rust parity port).
"""
# start maturin patch
def _maturin_dll_patch():
    import os
    import sys
    libs_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, "navette_color.libs"))
    if os.path.isdir(libs_dir):
        if sys.version_info >= (3, 8) and hasattr(os, 'add_dll_directory'):
            os.add_dll_directory(libs_dir)
_maturin_dll_patch()
del _maturin_dll_patch
# end maturin patch

# Import the compiled Rust extension so it is immediately available
# when someone imports the 'navette' namespace.
from . import color

# Define what gets exported if someone runs `from navette import *`
__all__ = ["color"]