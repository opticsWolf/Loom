"""
navette
=======

Fast univariate interpolation with multiple methods and batch support.
"""

# Import the compiled Rust extension so it is immediately available
from . import interpolate

# Define what gets exported if someone runs `from navette import *`
__all__ = ["interpolate"]